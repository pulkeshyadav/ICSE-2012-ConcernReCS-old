/* ConcernMapper - A concern modeling plug-in for Eclipse
 * Copyright (C) 2006  McGill University (http://www.cs.mcgill.ca/~martin/cm)
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * $Revision: 1.7 $
 */

package ca.mcgill.cs.serg.cm.model.io;

/**
 * A problem with the conversion of Java elements into unique 
 * string IDs.
 */
public class ConversionException extends Exception 
{
	/**
	 * Creates a new ConversionException.
	 * @param pMessage A message for the exception.
	 */
	public ConversionException( String pMessage )
	{ super( pMessage ); }
	
	/**
	 * Creates a new ConversionException.
	 * @param pMessage A message for the exception.
	 * @param pException A nested exception.
	 */
	public ConversionException( String pMessage, Throwable pException ) 
	{ super( pMessage, pException ); }
	
	/**
	 * Creates a new ConversionException.
	 * @param pException A nested exception.
	 */
	public ConversionException( Throwable pException ) 
	{ super( pException ); }
}
